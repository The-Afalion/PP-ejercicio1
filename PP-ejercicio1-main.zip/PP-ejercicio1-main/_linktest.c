#include <stdio.h>
int main(void){fprintf(stdout,"ok\n"); return 0;}
